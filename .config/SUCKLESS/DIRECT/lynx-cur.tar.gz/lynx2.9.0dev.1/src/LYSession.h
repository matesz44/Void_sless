/* $LynxId: LYSession.h,v 1.3 2008/02/10 23:47:39 Paul.B.Mahol Exp $ */
#ifndef LYSESSION_H
#define LYSESSION_H

#include <HTUtils.h>

#ifdef __cplusplus
extern "C" {
#endif
    extern void RestoreSession(void);
    extern void SaveSession(void);

#ifdef __cplusplus
}
#endif
#endif				/* LYSESSION_H */
